#include<iostream>
#include "point.h"

using namespace std;

void point::display()
{
    cout<<"("<<x<<", "<<y<<")"<<endl;
}
